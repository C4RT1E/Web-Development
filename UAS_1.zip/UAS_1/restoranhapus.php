<?php 
	include "includes/config.php";
	if(isset($_GET['hapusfoto']))
	{
		$restokode = $_GET['hapusfoto'];
		$hapusfoto = mysqli_query($connection, "SELECT * FROM restoran
			WHERE restoID = '$restokode'");
		$hapus = mysqli_fetch_array($hapusfoto);
		$namafile = $hapus['fotoresto'];

		mysqli_query($connection, "DELETE FROM restoran
			WHERE restoID = '$restokode'");
		unlink('images3/'.$namafile);

		echo "<script>alert('DATA TELAH DIHAPUS');
		document.location='restoran.php'</script>";
	}
?>