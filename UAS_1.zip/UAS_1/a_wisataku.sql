-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2022 at 08:16 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a_wisataku`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` char(4) NOT NULL,
  `adminNAMA` varchar(30) NOT NULL,
  `adminEMAIL` varchar(60) NOT NULL,
  `adminPASSWORD` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `adminNAMA`, `adminEMAIL`, `adminPASSWORD`) VALUES
('AD00', 'UAS', 'uas@yahoo.com', '1234'),
('AD01', 'uas', 'UAS@YAHOO.COM', '1234'),
('AD02', 'UAs', 'UAS@yahoo.com', '1234'),
('AD04', 'Rahma Della', 'rahmadellasafitri@gmail.com', '2412riri');

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `areaID` char(4) NOT NULL,
  `areanama` char(35) NOT NULL,
  `areawilayah` char(35) NOT NULL,
  `areaketerangan` varchar(255) NOT NULL,
  `provinsiID` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`areaID`, `areanama`, `areawilayah`, `areaketerangan`, `provinsiID`) VALUES
('A005', 'Denpasar', 'Pulau Bali', 'Destinasi wisata favorit', 'D4'),
('A006', 'Kepulauan Seribu', 'DKI Jakarta', 'Salah satu destinasi favorit', 'B1'),
('A007', 'Purwokerto', 'Pulau Jawa', 'Salah satu kota di Jawa Tengah', 'B2'),
('A008', 'Bandung', 'Pulau Jawa', 'Kota terkenal', 'C5'),
('A009', 'Lombok', 'Pulau NTB', 'Destinasi wisata favorit', 'F5'),
('A011', 'Kabupaten Raja Ampat', 'Papua Barat', 'Destinasi wisata laut', 'E6'),
('A012', 'Jogja', 'Pulau Jawa', 'Kota terkenal', 'J5'),
('A013', 'Kabupaten Pandeglang', 'Pulau Jawa', 'Kabupaten yang berada di provinsi Banten', 'U7'),
('A014', 'Labuan Bajo', 'Kecamatan Komodo', 'Desa di NTT', 'S8'),
('A015', 'Jakarta Pusat', 'DKI Jakarta', 'Salah satu kota bagian dari ibukota Indonesia', 'B1');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `beritaID` int(4) NOT NULL,
  `beritajudul` varchar(100) NOT NULL,
  `beritainti` varchar(100) NOT NULL,
  `penulis` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `destinasi`
--

CREATE TABLE `destinasi` (
  `destinasiID` char(5) NOT NULL,
  `destinasinama` varchar(35) NOT NULL,
  `destinasialamat` varchar(255) NOT NULL,
  `kategoriID` char(4) NOT NULL,
  `areaID` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `destinasi`
--

INSERT INTO `destinasi` (`destinasiID`, `destinasinama`, `destinasialamat`, `kategoriID`, `areaID`) VALUES
('WS01', 'Dago Pakar Bandung', 'Jalan Geger Kalor Hilir Bandung Utara', 'WK01', 'A008'),
('WS02', 'Lembang Asih', 'Jalan Lembang Utara', 'WK01', 'A008'),
('WS03', 'Pantai Krakal Jawa', 'Ngestirejo, Kec. Tanjungsari, Kabupaten Gunung Kidul, Yogyakarta', 'WK04', 'A012'),
('WS04', 'Pantai Kuta Bali', 'Kuta, Kabupaten Badung, Bali', 'WK04', 'A005'),
('WS05', 'Pantai Carita Anyer', 'Sukarame, Carita, Kabupaten Pandeglang, Banten 42264', 'WK04', 'A013'),
('WS06', 'Pantai Timbul', 'Raja Ampat, Papua Barat', 'WK04', 'A011'),
('WS07', 'Desa Labuan Bajo', 'Kecamatan Komodo, Kabupaten Manggarai Barat, provinsi Nusa Tenggara Timur', 'WK01', 'A014'),
('WS08', 'Masjid Istiqlal', 'l. Taman Wijaya Kusuma, Ps. Baru, Kecamatan Sawah Besar, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta', 'WK05', 'A015');

-- --------------------------------------------------------

--
-- Table structure for table `fotodestinasi`
--

CREATE TABLE `fotodestinasi` (
  `fotoID` char(5) NOT NULL,
  `fotonama` char(60) NOT NULL,
  `destinasiID` char(4) NOT NULL,
  `fotofile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fotodestinasi`
--

INSERT INTO `fotodestinasi` (`fotoID`, `fotonama`, `destinasiID`, `fotofile`) VALUES
('F002', 'Ranca Upas', 'WS01', 'rancaupas.jpg'),
('F003', 'Pantai Kuta', 'WS04', 'pantai.jpg'),
('F004', 'Pantai Carita Anyer', 'WS05', 'bali.jpg'),
('F006', 'Pantai Timbul', 'WS06', 'raja.jpg'),
('F007', 'Pantai Labuan Bajo', 'WS07', 'bajo.jpg'),
('F008', 'The Lodge Maribaya', 'WS02', 'maribaya.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `hotelID` char(5) NOT NULL,
  `hotelnama` varchar(35) NOT NULL,
  `areaID` char(4) NOT NULL,
  `fotohotel` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`hotelID`, `hotelnama`, `areaID`, `fotohotel`) VALUES
('Tel01', 'The Papandayan Bandung', 'A008', 'papandayan2.jpg'),
('Tel02', 'Aryaduta Hotel', 'A008', 'aryaduta.jpg'),
('Tel03', 'Kuta Paradiso Hotel', 'A005', 'paradiso.jpg'),
('Tel04', 'Pandeglang Raya Hotel', 'A013', 'pandeglang.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kabupaten`
--

CREATE TABLE `kabupaten` (
  `areaID` int(4) NOT NULL,
  `areaNama` int(100) NOT NULL,
  `areaWilayah` int(100) NOT NULL,
  `areaketerangan` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `kategoriID` char(4) NOT NULL,
  `kategorinama` char(30) NOT NULL,
  `kategoriketerangan` varchar(255) NOT NULL,
  `kategorireferensi` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`kategoriID`, `kategorinama`, `kategoriketerangan`, `kategorireferensi`) VALUES
('WK01', 'Alam', 'Wisata dengan pemandangan', 'Buku'),
('WK02', 'Hiburan', 'Taman Bermain', 'Katalog'),
('WK03', 'Museum', 'Tempat Bersejarah', 'Majalah'),
('WK04', 'Pantai', 'Wisata Laut', 'Majalah'),
('WK05', 'Religi', 'Tempat Peribadatan', 'Buku');

-- --------------------------------------------------------

--
-- Table structure for table `konfirmasi`
--

CREATE TABLE `konfirmasi` (
  `ID` char(4) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `konfirmasi`
--

INSERT INTO `konfirmasi` (`ID`, `nama`, `email`, `isi`) VALUES
('A1', 'Ririrubyjane', 'ririrubyjane@gmail.com', 'Website ini sangat bagus dan bermanfaat untuk mengetahui destinasi wisata'),
('A2', 'Lulu', 'luluthfan@yahoo.com', 'Saya sangat suka dengan website ini, terima kasih');

-- --------------------------------------------------------

--
-- Table structure for table `provinsi`
--

CREATE TABLE `provinsi` (
  `provinsiID` char(2) NOT NULL,
  `provinsinama` char(25) NOT NULL,
  `provinsitglberdiri` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `provinsi`
--

INSERT INTO `provinsi` (`provinsiID`, `provinsinama`, `provinsitglberdiri`) VALUES
('B1', 'DKI Jakarta', '1527-06-22'),
('B2', 'Jawa Tengah', '2020-12-09'),
('C5', 'Jawa Barat', '1667-10-05'),
('D4', 'Bali', '1887-02-05'),
('E6', 'Papua', '1556-02-09'),
('F5', 'Nusa Tenggara Barat', '1778-09-20'),
('J5', 'Yogyakarta', '1677-05-24'),
('S8', 'Nusa Tenggara Timur', '1887-09-08'),
('U7', 'Banten', '1667-04-15');

-- --------------------------------------------------------

--
-- Table structure for table `reservasi`
--

CREATE TABLE `reservasi` (
  `reservasiID` char(4) NOT NULL,
  `namaanggota` varchar(500) NOT NULL,
  `areaID` char(5) NOT NULL,
  `destinasiID` char(5) NOT NULL,
  `hotelID` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservasi`
--

INSERT INTO `reservasi` (`reservasiID`, `namaanggota`, `areaID`, `destinasiID`, `hotelID`) VALUES
('RSV1', 'Rahma Della Safitri', 'A008', 'WS02', 'Tel01'),
('RSV2', 'Aldea', 'A012', 'WS03', 'Tel02'),
('RSV3', 'Jennie Kim', 'A005', 'WS05', 'Tel04');

-- --------------------------------------------------------

--
-- Table structure for table `restoran`
--

CREATE TABLE `restoran` (
  `restoID` char(6) NOT NULL,
  `restonama` varchar(100) NOT NULL,
  `areaID` char(4) NOT NULL,
  `fotoresto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restoran`
--

INSERT INTO `restoran` (`restoID`, `restonama`, `areaID`, `fotoresto`) VALUES
('Res01', 'Maja House Bandung', 'A008', 'maja.jpg'),
('Res04', 'Goemerot Restaurant', 'A005', 'goemerot.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`areaID`) USING BTREE;

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`beritaID`);

--
-- Indexes for table `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`destinasiID`);

--
-- Indexes for table `fotodestinasi`
--
ALTER TABLE `fotodestinasi`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`hotelID`);

--
-- Indexes for table `kabupaten`
--
ALTER TABLE `kabupaten`
  ADD PRIMARY KEY (`areaID`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kategoriID`);

--
-- Indexes for table `konfirmasi`
--
ALTER TABLE `konfirmasi`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `provinsi`
--
ALTER TABLE `provinsi`
  ADD PRIMARY KEY (`provinsiID`);

--
-- Indexes for table `reservasi`
--
ALTER TABLE `reservasi`
  ADD PRIMARY KEY (`reservasiID`);

--
-- Indexes for table `restoran`
--
ALTER TABLE `restoran`
  ADD PRIMARY KEY (`restoID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
