<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WISATA</title>
</head>

<?php
ob_start();
session_start();
if(!isset($_SESSION['emailuser']))
  header("location:login.php");
?>
<?php include "header.php";?>

<div class="container-fluid">
<div class="card shadow mb-4">

<?php
  include "includes/config.php";

  if(isset($_POST['Batal']))
  {
    header("location:provinsi.php");
  }

  if(isset($_POST['Edit']))
  {
    if (isset($_REQUEST['inputprovinsi']))
    {
      $kategoriprovinsi = $_REQUEST['inputprovinsi'];
    }

    if (!empty($kategoriprovinsi))
    {
      $kategoriprovinsi = $_REQUEST['inputprovinsi'];
    }
    else {
      die ("Anda harus memasukkan kodenya");
    }

    $kategorinama = $_POST['inputprovinsinama'];
    $kategoritanggal = $_POST['inputtgl'];

    mysqli_query($connection,"update provinsi set provinsinama='$kategorinama', provinsitglberdiri='$kategoritanggal'
      WHERE provinsiID= '$kategoriprovinsi'");
    header("location:provinsi.php");    
  }


// utk menampilkan data pada form edit
$kodeprovinsi = $_GET["ubah"];
$editprovinsi = mysqli_query($connection, "SELECT * FROM provinsi WHERE provinsiID = 
'$kodeprovinsi'");
$rowedit = mysqli_fetch_array($editprovinsi);

?>



<div class="row">
<div class="col-sm-1">
</div>
<div class="col-sm-10">

    <div class="jumbotron jumbotron-fluid">
        <div class="container">
          <h1 class="display-4">Edit Provinsi Wisata</h1>
        </div>
      </div>

  <form method="POST">
  <div class="form-group row">
    <label for="provinsiID" class="col-sm-2 col-form-label">Provinsi ID</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="provinsiID" name="inputprovinsi" value="<?php echo$rowedit["provinsiID"]?>" readonly>
    </div>
  </div>

  <div class="form-group row">
    <label for="provinsinama" class="col-sm-2 col-form-label">Nama Provinsi</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="inputprovinsinama" id="provinsinama" value="<?php echo$rowedit["provinsinama"]?>">
    </div>
  </div>

  <div class="form-group row">
    <label for="tglberdiri" class="col-sm-2 col-form-label">Tanggal Berdiri Provinsi</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="inputtgl" id="tglberdiri" value="<?php echo$rowedit["provinsitglberdiri"]?>">
    </div>
  </div>

  
<div class="form-group row">
  <div class="col-sm-2">
  </div>
  <div class="col-sm-10">
    <input type="submit" class="btn btn-primary" value="Edit" name="Edit">
    <input type="submit" class="btn btn-secondary" value="Batal" name="Batal">
  </div>
</div>

  </form>
</div>

<div class="col-sm-1">
</div>
</div> <!--penutup class row -->


<!--memulai dgn menampilkan data -->
 <div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
      <div class="jumbotron jumbotron-fluid">
        <div class="container">
          <h1 class="display-4">Daftar Provinsi Wisata</h1>
          <h2>Hasil entri data pada tabel provinsi</h2>
        </div>
      </div> <!--penutup jumbotron -->

<form method="POST">
  <div class="form-group row mb-2">
    <label for="search" class="col-sm-3">Nama Provinsi</label>
    <div class="col-sm-6">
      <input type="text" name="search" class="form-control" id="search" value="<?php if(isset($_POST['search'])) {echo $_POST['search'];}?>" placeholder="Cari nama provinsi">
    </div>
    <input type="submit" name="kirim" class="col-sm-1 btn btn-primary" value="Search">
  </div>
</form>

<table class="table table-hover table-danger">
      <thead class="thead-dark">
        <tr>
          <th>No</th>
          <th>Provinsi ID</th>
          <th>Nama Provinsi</th>
          <th>Tanggal Berdiri</th>

          <th colspan="2" style="text-align: center">Action</th>
        </tr>
      </thead>

      <tbody>
      <?php 
      if(isset($_POST["kirim"]))
      {
        $search = $_POST['search'];
        $query = mysqli_query($connection, "select * from provinsi
          where provinsinama  like '%".$search."%'
          or provinsitglberdiri like '%".$search."%' ");
      }else

      {
        $query = mysqli_query($connection, "select * from provinsi");
      }

      $nomor = 1;
      while ($row = mysqli_fetch_array($query))
      { ?>
        <tr>
        <td><?php echo $nomor;?></td>
        <td><?php echo $row['provinsiID'];?></td>
        <td><?php echo $row['provinsinama'];?></td>
        <td><?php echo $row['provinsitglberdiri'];?></td>
      
      <td>
<a href="provinsiedit.php?ubah=<?php echo $row["provinsiID"]?>"
  class="btn btn-success btn-sm" title="EDIT">
<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg" title="edit">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg>
</a>
</td>

<td>
  <a href="provinsihapus.php?hapus=<?php echo $row["provinsiID"]?>"
  class="btn btn-danger btn-sm" title="DELETE">
  <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
</svg>
</a>
</td>
<!-- akhir icon edit delete -->
        </tr>
      <?php $nomor = $nomor + 1; ?>
      <?php } ?>
      </tbody>
    </table>
    </div>

    <div class="col-sm-1"></div>
  </div>





    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</div>
</div>
<?php include "footer.php";?>
<?php
mysqli_close($connection);
ob_end_flush();
?>

</html>