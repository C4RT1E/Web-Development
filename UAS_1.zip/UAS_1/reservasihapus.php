<?php
	include "includes/config.php";
	if(isset($_GET['hapus'])){
		$kodereservasi = $_GET["hapus"];
		mysqli_query($connection, "DELETE FROM reservasi WHERE reservasiID = '$kodereservasi'");
		echo "<script>alert('DATA BERHASIL DIHAPUS');
			document.location = 'reservasi.php'</script>";
	}
?>